// GrievancesAdapter.kt

package com.project.mxlabs

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GrievancesAdapter(private val context: Context, private val grievancesList: List<Grievance>) :
    RecyclerView.Adapter<GrievancesAdapter.GrievanceViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GrievanceViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.list_item_grievance, parent, false)
        return GrievanceViewHolder(view)
    }

    override fun onBindViewHolder(holder: GrievanceViewHolder, position: Int) {
        val grievance = grievancesList[position]
        holder.bind(grievance)
    }

    override fun getItemCount(): Int {
        return grievancesList.size
    }

    inner class GrievanceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewGrievance: TextView = itemView.findViewById(R.id.textViewGrievance)

        fun bind(grievance: Grievance) {
            val black = Color.BLACK
            val darkBrown = Color.parseColor("#814B41")
            val darkGreen = Color.parseColor("#267C26")
            val darkRed = Color.parseColor("#BD2C2C")
            val darkBlue = Color.parseColor("#FF01579B")
//            val darkBrown = Color.parseColor("#FFDC8E7F")
//            val darkGreen = Color.parseColor("#B390EE90")
//            val darkRed = Color.parseColor("#FFFF7F7F")
//            val darkBlue = Color.parseColor("#802C3D6E")
//            val lightBrown = Color.parseColor("#DC8E7F")
//            val lightGreen = Color.parseColor("#90EE90")
//            val lightRed = Color.parseColor("#FF7F7F")
//            val lightBlue = Color.parseColor("#2C3D6E")


            val typeText = "Grievance type:\t\t${grievance.type}"
            val labText = "Lab:\t\t${grievance.lab}"
            val systemNoText = "System No:\t\t${grievance.systemNo}"
            val descriptionText = "Description:\t\t${grievance.description}"
            val statusText = "Status:\t\t${grievance.status}"

            val formattedString = "$typeText\n$labText\n$systemNoText\n$descriptionText\n$statusText"
            val spannableString = SpannableString(formattedString)

            // Apply styles for labels
            spannableString.setSpan(StyleSpan(Typeface.BOLD), 0, 15, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannableString.setSpan(ForegroundColorSpan(black), 0, 15, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

            spannableString.setSpan(StyleSpan(Typeface.BOLD), typeText.length + 1, typeText.length + 1 + 4, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannableString.setSpan(ForegroundColorSpan(black), typeText.length + 1, typeText.length + 1 + 4, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

            spannableString.setSpan(StyleSpan(Typeface.BOLD), typeText.length + 1 + labText.length + 1, typeText.length + 1 + labText.length + 1 + 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannableString.setSpan(ForegroundColorSpan(black), typeText.length + 1 + labText.length + 1, typeText.length + 1 + labText.length + 1 + 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

            spannableString.setSpan(StyleSpan(Typeface.BOLD), typeText.length + 1 + labText.length + 1 + systemNoText.length + 1, typeText.length + 1 + labText.length + 1 + systemNoText.length + 1 + 12, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannableString.setSpan(ForegroundColorSpan(black), typeText.length + 1 + labText.length + 1 + systemNoText.length + 1, typeText.length + 1 + labText.length + 1 + systemNoText.length + 1 + 12, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

            spannableString.setSpan(StyleSpan(Typeface.BOLD), typeText.length + 1 + labText.length + 1 + systemNoText.length + 1 + descriptionText.length + 1, typeText.length + 1 + labText.length + 1 + systemNoText.length + 1 + descriptionText.length + 1 + 8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannableString.setSpan(ForegroundColorSpan(black), typeText.length + 1 + labText.length + 1 + systemNoText.length + 1 + descriptionText.length + 1, typeText.length + 1 + labText.length + 1 + systemNoText.length + 1 + descriptionText.length + 1 + 8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

            // Status color and background
            val statusStart = grievance.status?.let { formattedString.indexOf(it) }
            val statusEnd = statusStart?.plus(grievance.status.length)
            val statusColor = when (grievance.status) {
                "Submitted" -> darkBrown
                "Completed" -> darkGreen
                "Rejected" -> darkRed
                "In Progress" -> darkBlue
                else -> black
            }

            // Set status text color to black to ensure visibility over the background
            val statusTextColor = black

            if (statusStart != null && statusEnd != null) {
                spannableString.setSpan(ForegroundColorSpan(statusTextColor), statusStart, statusEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                spannableString.setSpan(BackgroundColorSpan(statusColor), statusStart, statusEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }

            textViewGrievance.text = spannableString
        }
    }
}
