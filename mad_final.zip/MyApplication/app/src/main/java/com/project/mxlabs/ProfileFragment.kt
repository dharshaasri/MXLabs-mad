package com.project.mxlabs

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ProfileFragment : Fragment() {

    private lateinit var grievancesRef: DatabaseReference
    private lateinit var username: String
    private lateinit var email: String
    private lateinit var className: String
    private lateinit var rollNumber: String

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)
        val database = FirebaseDatabase.getInstance()
        username = requireActivity().intent.getStringExtra("username") ?: "Unknown"
        email = requireActivity().intent.getStringExtra("email")?.replace(".", "_") ?: "DefaultEmail"
        className = requireActivity().intent.getStringExtra("class") ?: "DefaultClass"
        rollNumber = requireActivity().intent.getStringExtra("rollNumber") ?: "DefaultRollnumber"

        Log.d("ReportGrievanceFragment", "Username: $username")
        Log.d("ReportGrievanceFragment", "Email: $email")
        Log.d("ReportGrievanceFragment", "Class Name: $className")
        Log.d("ReportGrievanceFragment", "Roll Number: $rollNumber")

        if (rollNumber != null && username != null && className != null && email != null) {
            val usernameTextView = view.findViewById<TextView>(R.id.nameTextView)
            usernameTextView.text = "$username"
            val rollNumberTextView = view.findViewById<TextView>(R.id.rollNoTextView)
            rollNumberTextView.text = "ROLL NUMBER:\t\t$rollNumber"
            val classNameTextView = view.findViewById<TextView>(R.id.classTextView)
            classNameTextView.text = "CLASS:\t\t$className".uppercase()
            val emailTextView = view.findViewById<TextView>(R.id.emailTextView)
            emailTextView.text = "$email"?.replace("_", ".")
        }

        val logoutButton = view.findViewById<Button>(R.id.logoutButton)
        logoutButton.setOnClickListener {
            // Sign out user
            FirebaseAuth.getInstance().signOut()
            // Clear shared preferences
            val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.clear()
            editor.apply()
            // Navigate to LoginActivity
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
            // Finish current activity
            requireActivity().finish()
        }


//        val changePasswordButton = view.findViewById<Button>(R.id.changePasswordButton)
//        changePasswordButton.setOnClickListener {
//            showChangePasswordDialog()
//        }

        return view
    }

//    private fun showChangePasswordDialog() {
//        val builder = AlertDialog.Builder(requireContext())
//        builder.setTitle("Change Password")
//
//        val view = layoutInflater.inflate(R.layout.dialog_change_password, null)
//        val currentPasswordEditText = view.findViewById<EditText>(R.id.currentPasswordEditText)
//        val newPasswordEditText = view.findViewById<EditText>(R.id.newPasswordEditText)
//
//        builder.setView(view)
//
//        builder.setPositiveButton("Change") { _, _ ->
//            val currentPassword = currentPasswordEditText.text.toString()
//            val newPassword = newPasswordEditText.text.toString()
//
//            // Validate input fields
//            if (currentPassword.isEmpty() || newPassword.isEmpty()) {
//                Toast.makeText(requireContext(), "Please enter both current and new password", Toast.LENGTH_SHORT).show()
//                return@setPositiveButton
//            }
//
//            // Get current user
//            val user = FirebaseAuth.getInstance().currentUser
//            if (user != null && user.email != null) {
//                // Reauthenticate user
//                val credential = EmailAuthProvider.getCredential(user.email!!, currentPassword)
//                user.reauthenticate(credential)
//                    .addOnSuccessListener {
//                        // Change password
//                        user.updatePassword(newPassword)
//                            .addOnSuccessListener {
//                                Toast.makeText(requireContext(), "Password changed successfully", Toast.LENGTH_SHORT).show()
//                            }
//                            .addOnFailureListener { e ->
//                                Toast.makeText(requireContext(), "Failed to change password: ${e.message}", Toast.LENGTH_SHORT).show()
//                            }
//                    }
//                    .addOnFailureListener { e ->
//                        Toast.makeText(requireContext(), "Authentication failed: ${e.message}", Toast.LENGTH_SHORT).show()
//                    }
//            }
//        }
//
//        builder.setNegativeButton("Cancel") { dialog, _ ->
//            dialog.dismiss()
//        }
//
//        builder.create().show()
//    }
}
