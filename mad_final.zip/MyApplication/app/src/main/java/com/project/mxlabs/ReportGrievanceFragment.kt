package com.project.mxlabs

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener

class ReportGrievanceFragment : Fragment() {

    private lateinit var grievancesRef: DatabaseReference
    private lateinit var username: String
    private lateinit var email: String
    private lateinit var className: String
    private lateinit var rollNumber: String// Variable to hold the username
    private val labOptions: MutableList<String> = mutableListOf()
    private val systemOptions: MutableList<String> = mutableListOf()
    private val dynamicOptions: MutableList<String> = mutableListOf()

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_report_grievance, container, false)
        val database = FirebaseDatabase.getInstance()
        grievancesRef = database.reference.child("grievances")
        val systemSpinner: Spinner = view.findViewById(R.id.system_no_edit_text)

        val labsRef = database.reference.child("labs")
        labsRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                labOptions.clear()
                for (labSnapshot in dataSnapshot.children) {
                    val labName = labSnapshot.child("labName").getValue(String::class.java)
                    Log.d("Data stored", "lab$labName")
                    labName?.let { labOptions.add(it) }
                }
                // Populate the dropdown with lab options
                val labSpinner: Spinner = view.findViewById(R.id.lab_spinner)
                val labAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, labOptions)
                labAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                labSpinner.adapter = labAdapter

                // Set OnItemSelectedListener after populating lab options
                labSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                        // Clear the systemOptions list
                        systemOptions.clear()
                        val selectedLab = labOptions[position]
                        val selectedLabRef = database.reference.child("labs").child(selectedLab).child("systems")

                        // Add a listener to retrieve system numbers for the selected lab
                        selectedLabRef.addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                for (systemSnapshot in dataSnapshot.children) {
                                    val systemNumber = systemSnapshot.child("systemNumber").getValue(String::class.java)
                                    Log.d("Data stored", "systemNumber$systemNumber")
                                    systemNumber?.let { systemOptions.add(it) }
                                }
                                //  val systemSpinner: Spinner = view?.findViewById(R.id.system_no_edit_text) as Spinner
                                val systemAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, systemOptions)
                                systemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                                systemSpinner.adapter = systemAdapter
                            }

                            override fun onCancelled(databaseError: DatabaseError) {
                                // Handle error
                                Toast.makeText(requireContext(), "Failed to fetch system options", Toast.LENGTH_SHORT).show()
                            }
                        })
                    }

                    override fun onNothingSelected(parent: AdapterView<*>) {
                        // Handle case where nothing is selected (optional)
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error
                Toast.makeText(requireContext(), "Failed to fetch lab options", Toast.LENGTH_SHORT).show()
            }
        })

        val typeSpinner: Spinner = view.findViewById(R.id.type_spinner)
        val dynamicOptionsSpinner: Spinner = view.findViewById(R.id.dynamic_options_spinner)
        //     val systemSpinner: Spinner = view.findViewById(R.id.system_no_edit_text)

        // ...

        typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedType = parent.getItemAtPosition(position) as String
                when (selectedType) {
                    "Hardware" -> {
                        systemSpinner.visibility = View.VISIBLE
                        dynamicOptionsSpinner.visibility = View.VISIBLE
                        dynamicOptions.clear()
                        dynamicOptions.addAll(listOf("Monitor", "Keyboard", "Mouse", "CPU", "Switch Plug", "Webcam", "Others"))
                        val dynamicAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, dynamicOptions)
                        dynamicAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        dynamicOptionsSpinner.adapter = dynamicAdapter
                    }
                    "Software" -> {
                        systemSpinner.visibility = View.VISIBLE
                        dynamicOptionsSpinner.visibility = View.GONE
                    }
                    "Others" -> {
                        systemSpinner.visibility = View.GONE
                        dynamicOptionsSpinner.visibility = View.VISIBLE
                        dynamicOptions.clear()
                        dynamicOptions.addAll(listOf("AC", "Fan", "Light", "Others"))
                        val dynamicAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, dynamicOptions)
                        dynamicAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        dynamicOptionsSpinner.adapter = dynamicAdapter
                    }
                    else -> {
                        systemSpinner.visibility = View.GONE
                        dynamicOptionsSpinner.visibility = View.GONE
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Handle case where nothing is selected (optional)
            }
        }

        // Retrieve the username from the intent extras
        // Retrieve the username from the intent extras
        username = requireActivity().intent.getStringExtra("username")?: "Unknown"
        email = requireActivity().intent.getStringExtra("email") ?.replace(".", "_") ?: "DefaultEmail"
        className = requireActivity().intent.getStringExtra("class") ?: "DefaultClass"
        rollNumber = requireActivity().intent.getStringExtra("rollNumber") ?: "DefaultRollnumber"

        Log.d("ReportGrievanceFragment", "Username: $username")
        Log.d("ReportGrievanceFragment", "Email: $email")
        Log.d("ReportGrievanceFragment", "Class Name: $className")
        Log.d("ReportGrievanceFragment", "Roll Number: $rollNumber")

        if (rollNumber != null && username!=null && className!=null&&email!=null) {
            // Use the username as needed
            // For example, display it in a TextView
            val usernameTextView = view.findViewById<TextView>(R.id.username_text)
            usernameTextView.text = "Name:\t\t$username"
            val rollNumberTextView = view.findViewById<TextView>(R.id.roll_number_text)
            rollNumberTextView.text = "Roll No:\t\t$rollNumber".uppercase()
            val classNameTextView = view.findViewById<TextView>(R.id.class_text)
            classNameTextView.text = "Class:\t\t$className".uppercase()
            val emailTextView = view.findViewById<TextView>(R.id.email_text)
            emailTextView.text = "Mail ID:\t\t$email"?.replace("_", ".")
        }

        val grievanceEditText: EditText = view.findViewById(R.id.grievance_edit_text)
        //   val typeSpinner: Spinner = view.findViewById(R.id.type_spinner)
        val labSpinner: Spinner = view.findViewById(R.id.lab_spinner)
        //    val systemSpinner: Spinner = view.findViewById(R.id.system_no_edit_text)
        val descriptionEditText: EditText = view.findViewById(R.id.description_edit_text)
        val submitButton: Button = view.findViewById(R.id.submit_button)

        // Spinner (dropdown) for selecting type
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.types_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            typeSpinner.adapter = adapter
        }

        submitButton.setOnClickListener {
            val grievance = grievanceEditText.text.toString()
            val type = typeSpinner.selectedItem.toString()
            val lab = labSpinner.selectedItem.toString()
            val systemNo = systemSpinner.selectedItem.toString()
            val description = descriptionEditText.text.toString()
            val username = requireActivity().intent.getStringExtra("username") ?: "Unknown"
            val email = requireActivity().intent.getStringExtra("email") ?: "DefaultEmail"
            val className = requireActivity().intent.getStringExtra("class") ?: "DefaultClass"
            val rollNumber = requireActivity().intent.getStringExtra("rollNumber") ?: "DefaultRollNumber"
            val timestamp = ServerValue.TIMESTAMP
            // Saving data to Firebase using the passed username
            val grievanceData = HashMap<String, Any>()

            if (grievance.isEmpty() || type.isEmpty() || lab.isEmpty() || systemNo.isEmpty() || description.isEmpty()) {
                // Notify the user to fill in all required fields
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Exit the click listener
            }

            grievanceData["grievance"] = grievance
            grievanceData["type"] = type
            grievanceData["lab"] = lab
            grievanceData["systemNo"] = systemNo
            grievanceData["description"] = description
            grievanceData["username"] = username // Include username
            grievanceData["email"] = email // Include email
            grievanceData["className"] = className // Include className
            grievanceData["rollNumber"] = rollNumber // Include rollNumber
            grievanceData["status"]="Submitted"
            grievanceData["timestamp"] = timestamp
            Log.d("Data stored","Data stored $username")

            // Store grievance under the username
            grievancesRef.child(rollNumber).push().setValue(grievanceData)
                .addOnCompleteListener { task ->
                    Log.d("Data stored","setting$username")
                    if (task.isSuccessful) {
                        // Clear EditText fields on successful submission
                        grievanceEditText.text.clear()
                        descriptionEditText.text.clear()
                        Toast.makeText(
                            requireContext(),
                            "Grievance submitted successfully",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Failed to submit grievance",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
        return view
    }
}
